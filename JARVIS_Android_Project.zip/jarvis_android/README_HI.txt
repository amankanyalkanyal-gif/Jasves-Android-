JARVIS Android APK Project

IMPORTANT SECURITY:
- Uploaded Python source contained a Gemini API key. Revoke that old key in Google AI Studio.
- This project does NOT contain the old key. First launch asks you to enter a NEW key.
- The key is stored in this app's private preferences, not inside the source code. Do not share the APK with your key configured.

BUILD ON A PHONE (recommended: GitHub Actions cloud build):
1. Extract this ZIP.
2. In a browser, sign in to GitHub and create a NEW empty repository named jarvis-android.
3. Upload all files and folders from this extracted project to the repository (keep .github/workflows/android.yml).
4. Open the repository's Actions tab. Enable Actions if GitHub asks.
5. Run the workflow named Build JARVIS APK (or push a commit to main).
6. When it finishes, open the workflow run, scroll to Artifacts, and download jarvis-debug-apk.
7. Extract the artifact ZIP and install app-debug.apk. Android may ask permission to install apps from your browser/files app.

No Pydroid 3 or computer is needed for the cloud build. Building locally on an older low-RAM phone may be difficult.

APP NOTES:
- The existing HTML HUD is carried over into the Android WebView.
- Gemini calls, phone-private JSON-like memory, and opening selected installed apps are handled natively.
- Speech synthesis and browser speech recognition depend on Android WebView/Google speech services. Continuous wake-word listening may not work reliably in the background; it needs a later native foreground-service implementation.
- API model name preserved from the uploaded source: gemini-3.5-flash-lite. If Google reports that model unavailable, update the model string in MainActivity.kt to a currently enabled model in your AI Studio account.
