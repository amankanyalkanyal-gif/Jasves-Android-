package com.aman.jarvis

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("jarvis_private", MODE_PRIVATE) }
    private val model = "gemini-3.5-flash-lite"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(JarvisBridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (prefs.getString("api_key", null).isNullOrBlank()) {
            web.postDelayed({ showApiKeyDialog(false) }, 500)
        }
    }

    inner class JarvisBridge {
        @JavascriptInterface fun ask(message: String, requestId: String) {
            worker.execute {
                try {
                    val reply = handleMessage(message)
                    sendResult(requestId, reply, null)
                } catch (e: Exception) {
                    sendResult(requestId, "", e.message ?: "Anjaan error")
                }
            }
        }
        @JavascriptInterface fun openApp(name: String) {
            runOnUiThread {
                val packageName = when (name.lowercase()) {
                    "youtube" -> "com.google.android.youtube"
                    "chrome" -> "com.android.chrome"
                    "whatsapp" -> "com.whatsapp"
                    "instagram" -> "com.instagram.android"
                    "google" -> "com.google.android.googlequicksearchbox"
                    "settings" -> "com.android.settings"
                    else -> ""
                }
                try {
                    val intent = if (packageName.isNotEmpty()) packageManager.getLaunchIntentForPackage(packageName) else null
                    if (intent != null) startActivity(intent) else Toast.makeText(this@MainActivity, "$name app nahi mili", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) { Toast.makeText(this@MainActivity, "App nahi khul payi", Toast.LENGTH_SHORT).show() }
            }
        }
        @JavascriptInterface fun changeApiKey() { runOnUiThread { showApiKeyDialog(true) } }
    }

    private fun sendResult(id: String, reply: String, error: String?) {
        val js = "window.onNativeReply(${JSONObject.quote(id)},${JSONObject.quote(reply)},${if (error == null) "null" else JSONObject.quote(error)});"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun showApiKeyDialog(allowCancel: Boolean) {
        val input = EditText(this).apply {
            hint = "Gemini API key paste karein"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", "") ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("JARVIS · API Setup")
            .setMessage("Apni nayi Gemini API key yahan enter karein. Key sirf is app ke private storage mein rahegi.")
            .setView(input)
            .setCancelable(allowCancel)
            .setPositiveButton("SAVE") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isNotEmpty()) prefs.edit().putString("api_key", key).apply()
                else Toast.makeText(this, "API key khaali hai", Toast.LENGTH_SHORT).show()
            }
            .apply { if (allowCancel) setNegativeButton("CANCEL", null) }
            .show()
    }

    private fun localMemory(): JSONObject {
        return try { JSONObject(prefs.getString("memory", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    }
    private fun saveMemory(memory: JSONObject) { prefs.edit().putString("memory", memory.toString()).apply() }

    private fun handleMessage(raw: String): String {
        val message = raw.trim()
        if (message.isEmpty()) return "Sir, message khaali hai."
        val low = message.lowercase(Locale.ROOT)
        if (listOf("tumhe kisne banaya", "tumko kisne banaya", "who made you", "who created you", "jarvis ko kisne banaya").any { low.contains(it) }) {
            return "Ji Sir, JARVIS aapke Android project ka personal AI assistant hai, jise Aman Sir ne configure kiya hai. Jawab dene wala AI model Gemini API se aata hai."
        }
        val memory = localMemory()
        memory.put("name", "Aman"); memory.put("preferred_address", "Sir")
        val facts = memory.optJSONArray("facts") ?: JSONArray()
        val prefixes = listOf("yaad rakhna ki ", "yaad rakhna ", "ise yaad rakho: ", "is baat ko yaad rakho: ", "remember that ", "remember this: ", "please remember ")
        for (prefix in prefixes) if (low.startsWith(prefix)) {
            val fact = message.substring(prefix.length).trim()
            if (fact.isNotEmpty()) {
                var exists = false
                for (i in 0 until facts.length()) if (facts.optString(i).equals(fact, true)) exists = true
                if (!exists) facts.put(fact)
                while (facts.length() > 200) facts.remove(0)
                memory.put("facts", facts); saveMemory(memory)
                return "Ji Sir, maine ye baat aapki phone memory mein save kar di hai: $fact"
            }
        }
        if (listOf("tumhe mere baare mein kya yaad hai", "mere baare mein kya yaad hai", "meri memory dikhao", "show my memory", "what do you remember").any { low.contains(it) }) {
            val saved = mutableListOf("Naam: Aman", "Sambodhan: Sir")
            for (i in 0 until facts.length()) saved.add(facts.optString(i))
            return "Ji Sir, aapki saved memory:\n- " + saved.joinToString("\n- ")
        }
        val forgetPrefixes = listOf("ise bhool jao: ", "is baat ko bhool jao: ", "yaad se hatao: ", "bhool jao ", "forget this: ", "forget ", "remove memory: ")
        for (prefix in forgetPrefixes) if (low.startsWith(prefix)) {
            val target = message.substring(prefix.length).trim()
            val keep = JSONArray()
            for (i in 0 until facts.length()) { val f = facts.optString(i); if (!f.contains(target, true)) keep.put(f) }
            memory.put("facts", keep); saveMemory(memory)
            return "Ji Sir, memory update kar di hai."
        }
        val key = prefs.getString("api_key", null)
        if (key.isNullOrBlank()) throw Exception("Pehle JARVIS title par tap karke Gemini API key set karein.")
        return callGemini(key, message, memory)
    }

    private fun callGemini(key: String, message: String, memory: JSONObject): String {
        val date = SimpleDateFormat("yyyy-MM-dd EEEE HH:mm", Locale.getDefault()).apply { timeZone = TimeZone.getTimeZone("Asia/Kolkata") }.format(Date())
        val facts = memory.optJSONArray("facts") ?: JSONArray()
        val prompt = "You are JARVIS, a helpful personal AI assistant in Aman Sir's Android project. The user is Aman; always address him as Sir. Reply in the language the user uses. Plain text only, no markdown. Current India date/time: $date. Saved facts: $facts. Be accurate. User question: $message"
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        if (listOf("latest", "today", "news", "search the web", "internet par search", "naya update", "aaj ki khabar").any { message.contains(it, true) }) {
            body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"; conn.connectTimeout = 25000; conn.readTimeout = 60000; conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json"); conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw Exception("Gemini API error ($code): ${responseText.take(220)}")
        val result = JSONObject(responseText)
        val candidates = result.optJSONArray("candidates") ?: throw Exception("Gemini se jawab nahi mila.")
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("Gemini ka jawab khaali hai.")
        val out = StringBuilder()
        for (i in 0 until parts.length()) out.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        return out.toString().replace("**", "").replace("*", "").trim().ifEmpty { "Ji Sir, dobara puchhiye." }
    }

    override fun onDestroy() { super.onDestroy(); worker.shutdownNow(); web.removeJavascriptInterface("Android") }
}
